<?php
/**
 * Plugin Name: PDS Navigation
 * Plugin URI: https://pdsdev.io
 * Description: Mobile menu styles extension for WordPress Navigation block
 * Version: 1.0.0
 * Author: PDS Dev
 * Text Domain: pds-navigation
 * Domain Path: /languages
 * License: GPL v2 or later
 */

if (!defined('ABSPATH')) {
    exit;
}

define('PDS_NAVIGATION_VERSION', '1.0.0');
define('PDS_NAVIGATION_DIR', plugin_dir_path(__FILE__));
define('PDS_NAVIGATION_URL', plugin_dir_url(__FILE__));

class PDS_Navigation_Plugin
{
    private static $instance = null;

    public static function get_instance()
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct()
    {
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_assets'));
        add_filter('render_block_core/navigation', array($this, 'add_mobile_menu_attributes'), 10, 2);
    }

    public function enqueue_frontend_assets()
    {
        if (!file_exists(PDS_NAVIGATION_DIR . 'build/frontend.css')) {
            return;
        }

        wp_enqueue_style(
            'pds-navigation-frontend',
            PDS_NAVIGATION_URL . 'build/frontend.css',
            array(),
            PDS_NAVIGATION_VERSION
        );

        wp_enqueue_script(
            'pds-navigation-frontend',
            PDS_NAVIGATION_URL . 'build/frontend.js',
            array(),
            PDS_NAVIGATION_VERSION,
            true
        );

        wp_enqueue_script(
            'pds-menu-handler',
            PDS_NAVIGATION_URL . 'build/menu-handler.js',
            array('pds-navigation-frontend'),
            PDS_NAVIGATION_VERSION,
            true
        );

        wp_localize_script('pds-navigation-frontend', 'pdsNavigation', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce'   => wp_create_nonce('pds_navigation_nonce'),
        ));
    }

    public function add_mobile_menu_attributes($block_content, $block)
    {
        if (!isset($block['attrs']['pdsMobileMenu'])) {
            return $block_content;
        }

        $settings = $block['attrs']['pdsMobileMenu'];

        if (empty($settings['style']) || 'none' === $settings['style']) {
            return $block_content;
        }

        $data_attrs = array(
            'data-pds-mobile-menu' => esc_attr($settings['style']),
            'data-pds-menu-width'  => isset($settings['menuWidth']) ? (int) $settings['menuWidth'] : 320,
            'data-pds-overlay-opacity' => isset($settings['overlayOpacity']) ? (int) $settings['overlayOpacity'] : 50,
            'data-pds-animation-speed' => isset($settings['animationSpeed']) ? (int) $settings['animationSpeed'] : 300,
            'data-pds-breakpoint' => isset($settings['breakpoint']) ? (int) $settings['breakpoint'] : 768,
            'data-pds-close-on-overlay' => isset($settings['closeOnOverlay']) ? ($settings['closeOnOverlay'] ? 'true' : 'false') : 'true',
            'data-pds-close-on-escape' => isset($settings['closeOnEscape']) ? ($settings['closeOnEscape'] ? 'true' : 'false') : 'true',
            'data-pds-enable-submenus' => isset($settings['enableSubmenus']) ? ($settings['enableSubmenus'] ? 'true' : 'false') : 'false',
        );

        libxml_use_internal_errors(true);
        $dom = new DOMDocument();
        $dom->loadHTML($block_content, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);

        $errors = libxml_get_errors();
        libxml_clear_errors();

        $xpath = new DOMXPath($dom);
        $container = $xpath->query('//*[contains(@class, "wp-block-navigation__responsive-container")]')->item(0);

        if ($container) {
            foreach ($data_attrs as $key => $value) {
                $container->setAttribute($key, $value);
            }
            $block_content = trim($dom->saveHTML($container));
        }

        return $block_content;
    }
}

function pds_navigation_init()
{
    return PDS_Navigation_Plugin::get_instance();
}

pds_navigation_init();
